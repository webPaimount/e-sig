<?php


namespace Sk\SmartId\Exception;


class RequiredInteractionNotSupportedByAppException extends UserAccountException
{

}