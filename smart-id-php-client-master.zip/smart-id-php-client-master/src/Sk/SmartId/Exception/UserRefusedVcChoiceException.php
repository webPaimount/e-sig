<?php


namespace Sk\SmartId\Exception;


class UserRefusedVcChoiceException extends UserRefusedException
{

}