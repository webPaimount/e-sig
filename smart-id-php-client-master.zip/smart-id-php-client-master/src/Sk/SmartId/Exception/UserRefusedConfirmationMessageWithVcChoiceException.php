<?php


namespace Sk\SmartId\Exception;


class UserRefusedConfirmationMessageWithVcChoiceException extends UserRefusedException
{

}