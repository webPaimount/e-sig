<?php

namespace Sk\SmartId\Exception;

class UserSelectedWrongVerificationCodeException extends UserActionException
{

}