<?php


namespace Sk\SmartId\Exception;


class UserRefusedDisplayTextAndPinException extends UserRefusedException
{

}