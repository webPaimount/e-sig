<?php

namespace Sk\SmartId\Exception;

// Server is under maintenance, retry later.
class ServerMaintenanceException extends EnduringSmartIdException
{

}