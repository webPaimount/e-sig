<?php


namespace Sk\SmartId\Exception;


class UserRefusedConfirmationMessageException extends UserRefusedException
{

}