<?php


namespace Sk\SmartId\Exception;


class UserRefusedCertChoiceException extends UserRefusedException
{

}